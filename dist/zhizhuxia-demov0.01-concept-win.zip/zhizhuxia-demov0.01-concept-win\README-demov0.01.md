# 智助侠 demov0.01 概念版

这是 Windows 原生 WPF 桌面小工具概念版。

## 运行

1. 确认本机已安装 .NET Windows Desktop Runtime / SDK 和 Node.js。
2. 双击 `Zhizhuxia.Desktop.exe`。
3. 在 Windows 右下角托盘隐藏图标中找到智助侠图标，右键打开配置。
4. 填写智谱 API Key 后保存。

## 默认快捷键

- 显示 / 隐藏：`Ctrl + Alt + F9`
- 区域截图：`Ctrl + Alt + F10`

## 模型与流程

- 文本与视觉模型：智谱 GLM-5.2
- 本地服务：WPF 通过 `http://localhost:5177/api/chat` 调用随包携带的 Node 后端
- 搜索顺序：B站 -> 小黑盒

## 本地数据

配置会缓存在当前 Windows 用户目录：

`%LOCALAPPDATA%\Zhizhuxia\visual-settings.json`

该文件不包含在发布包中。
